<?php

namespace IntrepidGroup\SampleApplication\Entity;

/**
 * Class Book.
 *
 * This entity represents a single book and it's properties
 */
class Book
{
    private $title = '';
    private $author = '';
    private $category = '';
    private $language = '';
    private $year = 1970;
    private $rating = 0;

    public function __construct($title, $author, $category ,$language, $year, $rating)
    {
        $this->title = $title;
        $this->author = $author;
        $this->category= $category;
        $this->language = $language;
        $this->year = $year;
        $this->rating = $rating;
    }

    /**
     * @return string
     */
    public function getTitle()
    {
        return $this->title;
    }

    /**
     * @return string
     */
    public function getAuthor()
    {
        return $this->author;
    }

     public function getCategory()
    {
        return $this->category;
    }

    // Task 1. Add book category to the information we store about a book

    /**
     * @return string
     */
    public function getLanguage()
    {
        return $this->language;
    }

    /**
     * @return int
     */
    public function getYear()
    {
        return $this->year;
    }

    /**
     * @return int
     */
    public function getRating()
    {
        return $this->rating;
    }

    /**
     * @return array
     */
    public function toArray()
    {
        return [
            'title' => $this->getTitle(),
            'author' => $this->getAuthor(),
            'category' => $this->getCategory(),
            'language' => $this->getLanguage(),
            'rating' => $this->getRating(),
            'year' => $this->getYear(),
        ];
    }
}
