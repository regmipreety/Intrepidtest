<?php

namespace IntrepidGroup\SampleApplication\Repository;

use IntrepidGroup\SampleApplication\Entity\Book;

/**
 * Class StaticBookRepository.
 *
 * This class returns acts as a Book Repository for a statically defined list of books
 */
class StaticBookRepository implements BookRepositoryInterface
{
    private $books = [];

    public function __construct()
    {
        $this->preloadStaticBooks();
    }

    /**
     * Retrieve and return a collection of all books.
     *
     * @return Book[]
     */
    public function fetchAll()
    {
        $output = [];

        /* @var $book Book */
         foreach ($this->books as $book) {
            $output[] = $book->toArray();
         }



        return $output;
    }

    public function getEnglishOnly(){

       $output=[];

        foreach($this->books as $key => $value){
            if($value->getLanguage() == "English")
                $output[] = $value->toArray();
        }

        // Task 2. Only show English Language books

        // Desc sort
        usort($output,function($first,$second){
            return $first['year'] < $second['year'];
        });

        return $output;
    }

    // Task 3. Sort books by year of publication by default


    /**
     * Preload the static list of books.
     */
    private function preloadStaticBooks()
    {
        $this->books[] = new Book('Finnegans Wake', 'Janes Joyce', 'History','English', 1941, 3);
        $this->books[] = new Book('Don Quixote', 'Miguel De Cervantes','Travel', 'Spanish', 1615, 5);
        $this->books[] = new Book('The Making of Americans', 'Gertrude Stein', 'Civilization','English', 1925, 5);
        $this->books[] = new Book('The Stranger', 'Albert Camus', 'Drama','French', 1942, 4);
        $this->books[] = new Book('Pilgrims Progress', 'John Bunyan', 'Archeology','English', 1684, 4);
        $this->books[] = new Book('In Search of Lost Time', 'Marcel Proust', 'Spiritual','French', 1913, 1);
        $this->books[] = new Book('Pale Fire', 'Valdimir Nabokov', 'Romance', 'English', 1962, 4);
        $this->books[] = new Book('The Trial', 'Franz Kafka', 'Ficton','German', 1925, 2);
        $this->books[] = new Book('Ulysses', 'James Joyce','Non-Ficton', 'English', 1922, 3);
        $this->books[] = new Book('The Name of the Rose', 'Umberto Eco', 'Romance','Italian', 1980, 4);
        $this->books[] = new Book('The Gulag Archipelago', 'Aleksandr Solzhenitsyn', 'Horror','Russian', 1973, 4);
        $this->books[] = new Book('The Diary of a Young Girl', 'Anne Frank', 'Fantasy','Dutch', 1947, 2);
        $this->books[] = new Book('Gravity\'s Rainbow', 'Thomas Pynchon', 'Mystery','English', 1973, 2);
        $this->books[] = new Book('One Hundred Years of Solitude','Gabriel García Márquez', 'Thriller','Spanish', 1967, 5);
        $this->books[] = new Book('The Sound and the Fury', 'William Faulkner', 'Autobiography','English', 1929, 3);
        $this->books[] = new Book('Confusion of Feelings', 'Stefan Zweig', 'Politics','German', 1927, 3);
        $this->books[] = new Book('The Public Burning', 'Robert Coover', 'Textbook','English', 1977, 1);
        $this->books[] = new Book('The Joke', 'Milan Kundera', 'Thriller','Czech', 1967, 5);
    }
}
