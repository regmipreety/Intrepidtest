new Vue({
    el: '#app',
    data: {
      selectedRating: "", 
      books: [],
        
    },
    created: function() {
        this.books = window.__INITIAL_STATE__
    },
    methods: {
      
    },
    computed: {
      selected_rating: function(){
        let filteredBook= this.selectedRating
        return this.books.filter(function(book){
          let filtered = true
          if(filteredBook && filteredBook.length > 0){
            filtered = book.rating == filteredBook
          }
         return filtered

          }

        )},
        
          
        
      }
    })
    


    
