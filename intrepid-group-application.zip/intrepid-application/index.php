<?php
use IntrepidGroup\SampleApplication\Repository\StaticBookRepository;
use Twig\Environment;
use Twig\Loader\FilesystemLoader;

require_once __DIR__.'/vendor/autoload.php';

// Fetch the collection of books
$bookRepository = new StaticBookRepository();
$books = $bookRepository->getEnglishOnly();

// Render the homepage
$twig = new Environment(new FilesystemLoader(__DIR__.'/src/Twig'));

// Change Twig annotation so it doesn't conflict with Vue
$lexer = new \Twig\Lexer($twig, [
    'tag_variable' => ['${', '}'],
]);
$twig->setLexer($lexer);

$twig->display('html.twig', array('books' => json_encode($books)));
